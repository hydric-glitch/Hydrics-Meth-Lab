ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Meth"
ENT.Spawnable = true
ENT.Category = "Hydric's Meth Lab"

function ENT:SetupDataTables()
  self:NetworkVar("Bool", 1, "JustSpawned")
end
