AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
  self:SetModel("models/props_junk/rock001a.mdl")
  self:SetColor(Color(0, 255, 255, 255))
  self:PhysicsInit(SOLID_VPHYSICS)
  self:SetMoveType(MOVETYPE_VPHYSICS)
  self:SetSolid(SOLID_VPHYSICS)

  -- setting up a three second timer
  self.timer = CurTime()

  local phys = self:GetPhysicsObject()
  if phys:IsValid() then
    phys:Wake()
  end
end

function ENT:Think()
  if self:GetJustSpawned() then
    if CurTime() > self.timer + 3 then
      self.timer = 0
      self:SetJustSpawned(false)
    end
  end
end

function ENT:Use(act, call)
  if !self:GetJustSpawned() and act:IsPlayer() then
    act:addMoney(13000)
    self:Remove()
  end
end
