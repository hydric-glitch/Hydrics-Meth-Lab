ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Reaction Chamber"
ENT.Spawnable = true
ENT.Category = "Hydric's Meth Lab"

function ENT:SetupDataTables()
  self:NetworkVar("Int", 1, "MethProgress")
  self:NetworkVar("Int", 2, "MethylaminAmount")
  self:NetworkVar("Int", 3, "SulfurAmount")
  self:NetworkVar("Int", 4, "PhosphorusAmount")
  self:NetworkVar("Int", 5, "WaterAmount")
end
