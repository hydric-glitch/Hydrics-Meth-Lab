include("shared.lua")

surface.CreateFont("hydricsmethlabchamberdisplayfont", {
  font = "Arial",
  size = 13,
  weight = 500
})

function ENT:Draw()
  self:DrawModel()
end

hook.Add("HUDPaint", "hydicsmethlabchamberhud", function()
  local eye = LocalPlayer():GetEyeTrace()
  if eye.Entity:GetClass() == "chamber" then
    local dist = 200^2
    local pos = eye.Entity:GetPos()
    if LocalPlayer():GetPos():DistToSqr(pos) < dist then
      -- Set pos to screen
      pos = pos:ToScreen()
      -- Draw the GUI on the meth object
      surface.SetDrawColor(0, 0, 0, 155)
      surface.DrawRect(pos.x*.9, pos.y, 150, 75)
      -- Draw the name of the Entity
      draw.SimpleText("Reaction Chamber", "hydricsmethlabchamberdisplayfont", pos.x*.9, pos.y, color_white, ALIGN_TEXT_CENTER, ALIGN_TEXT_CENTER)
      -- Draw MethProgress
      draw.SimpleText("Progress: " .. eye.Entity:GetMethProgress(), "hydricsmethlabchamberdisplayfont", pos.x*.9, pos.y*1.025, color_white, ALIGN_TEXT_CENTER, ALIGN_TEXT_CENTER)
      -- Draw PhosphorusAmount
      draw.SimpleText("Phosphorus: " .. eye.Entity:GetPhosphorusAmount(), "hydricsmethlabchamberdisplayfont", pos.x*.9, pos.y*1.05, Color(255, 0, 0, 255), ALIGN_TEXT_CENTER, ALIGN_TEXT_CENTER)
      -- Draw MethylaminAmount
      draw.SimpleText("Methylamin: " .. eye.Entity:GetMethylaminAmount(), "hydricsmethlabchamberdisplayfont", pos.x*.9, pos.y*1.07, color_white, ALIGN_TEXT_CENTER, ALIGN_TEXT_CENTER)
      -- Draw SulfurAmount
      draw.SimpleText("Sulfur: " .. eye.Entity:GetSulfurAmount(), "hydricsmethlabchamberdisplayfont", pos.x*.9, pos.y*1.09, Color(255, 255, 0, 255), ALIGN_TEXT_CENTER, ALIGN_TEXT_CENTER)
      -- Draw WaterAmount
      draw.SimpleText("Water: " .. eye.Entity:GetWaterAmount(), "hydricsmethlabchamberdisplayfont", pos.x*.9, pos.y*1.11, Color(0, 0, 255, 150), ALIGN_TEXT_CENTER, ALIGN_TEXT_CENTER)
    end
  end
end)
