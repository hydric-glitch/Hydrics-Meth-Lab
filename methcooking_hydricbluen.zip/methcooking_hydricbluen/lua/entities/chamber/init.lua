AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
  self:SetModel("models/props_wasteland/laundry_washer001a.mdl")
  self:PhysicsInit(SOLID_VPHYSICS)
  self:SetMoveType(MOVETYPE_VPHYSICS)
  self:SetSolid(SOLID_VPHYSICS)
  self:SetTrigger(true)

  -- Timer set to CurTime()
  self.timer = CurTime()

  local phys = self:GetPhysicsObject()
  if phys:IsValid() then
    phys:Wake()
  end
end

function ENT:Think()
  local pos = self:GetPos()
  if self:GetMethylaminAmount() >= 100 and self:GetSulfurAmount() >= 25 and self:GetPhosphorusAmount() >= 150 and self:GetWaterAmount() >= 100 then
    -- check if timer has increased!
    if CurTime() > self.timer + 1 then
      -- reset timer
      self.timer = CurTime()
      -- add to MethProgress
      self:SetMethProgress(self:GetMethProgress() + 5)
    end
  end
  if self:GetMethProgress() >= 100 then
    -- Spawn Liquid Meth entity
    local liquidmeth = ents.Create("liquid_meth")
    liquidmeth:SetPos(pos)
    liquidmeth:Spawn()
    -- Reset NetworkVars
    self:SetMethProgress(0)
    self:SetMethylaminAmount(0)
    self:SetSulfurAmount(0)
    self:SetWaterAmount(0)
    self:SetPhosphorusAmount(0)
  end
end

function ENT:StartTouch(toucher)
  if toucher:GetClass() == "methylamin" then
    self:SetMethylaminAmount(self:GetMethylaminAmount() + 50)
    toucher:Remove()
  elseif toucher:GetClass() == "sulfur" then
    self:SetSulfurAmount(self:GetSulfurAmount() + 25)
    toucher:Remove()
  elseif toucher:GetClass() == "phosphorus" then
    self:SetPhosphorusAmount(self:GetPhosphorusAmount() + 50)
    toucher:Remove()
  elseif toucher:GetClass() == "water" then
    self:SetWaterAmount(self:GetWaterAmount() + 50)
    toucher:Remove()
  else
    return
  end
end
