AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
  self:SetModel("models/props_junk/garbage_glassbottle002a.mdl")
  self:SetColor(Color(0, 255, 255, 255))
  self:PhysicsInit(SOLID_VPHYSICS)
  self:SetMoveType(MOVETYPE_VPHYSICS)
  self:SetSolid(SOLID_VPHYSICS)

  local phys = self:GetPhysicsObject()
  if phys:IsValid() then
    phys:Wake()
  end
end

function ENT:Use()
  -- spawn the meth entity
  local meth = ents.Create("meth")
  meth:SetPos(Vector(self:GetPos()))
  meth:SetJustSpawned(true)
  meth:Spawn()
  -- destroy the frozen meth entity
  self:Remove()
end
