AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
  self:SetModel("models/props_wasteland/kitchen_fridge001a.mdl")
  self:PhysicsInit(SOLID_VPHYSICS)
  self:SetMoveType(MOVETYPE_VPHYSICS)
  self:SetSolid(SOLID_VPHYSICS)

  -- create timer
  self.timer = CurTime()

  local phys = self:GetPhysicsObject()
  if phys:IsValid() then
    phys:Wake()
  end
end

function ENT:Think()
  -- check if freezing
  if self:GetIsFreezing() then
    -- check if curtime is above timer
    if CurTime() > self.timer + 1 then
      -- reset timer
      self.timer = CurTime()
      -- increase FreezeProgress
      self:SetFreezeProgress(self:GetFreezeProgress() + 15)
    end
  end
  -- check if FreezeProgress is >= 100
  if self:GetFreezeProgress() >= 100 then
    -- store current position
    local pos = self:GetPos()
    -- spawn frozen_meth
    local frozenMeth = ents.Create("frozen_meth")
    frozenMeth:SetPos(Vector(pos.x-50, pos.y, pos.z+35))
    frozenMeth:Spawn()
    -- reset NetworkVars
    self:SetIsFreezing(false)
    self:SetFreezeProgress(0)
  end
end

function ENT:StartTouch(toucher)
  if toucher.Entity:GetClass() == "liquid_meth" then
    -- set IsFreezing to true
    self:SetIsFreezing(true)
    -- remove the toucher
    toucher:Remove()
  else
    return
  end
end
