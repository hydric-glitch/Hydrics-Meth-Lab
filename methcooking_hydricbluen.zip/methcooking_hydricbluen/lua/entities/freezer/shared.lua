ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Freezer"
ENT.Spawnable = true
ENT.Category = "Hydric's Meth Lab"

function ENT:SetupDataTables()
  self:NetworkVar("Int", 1, "FreezeProgress")
  self:NetworkVar("Bool", 2, "IsFreezing")
end
