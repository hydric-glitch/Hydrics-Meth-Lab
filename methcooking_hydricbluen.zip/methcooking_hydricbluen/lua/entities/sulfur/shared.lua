ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Sulfur"
ENT.Spawnable = true
ENT.Category = "Hydric's Meth Lab"
