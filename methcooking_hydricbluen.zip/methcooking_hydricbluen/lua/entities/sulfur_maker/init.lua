AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
  self:SetModel("models/props_lab/jar01a.mdl")
  self:PhysicsInit(SOLID_VPHYSICS)
  self:SetMoveType(MOVETYPE_VPHYSICS)
  self:SetSolid(SOLID_VPHYSICS)
  self:SetTrigger(true)
  -- The timer for how long it takes to make the sulfur
  self.timer = CurTime()

  local phys = self:GetPhysicsObject()
  if phys:IsValid() then
    phys:Wake()
  end
end

function ENT:Think()
  local pos = self:GetPos()
  if self:GetPhosphorusAmount() >= 50 and self:GetMethylaminAmount() >= 100 then
    if CurTime() > self.timer + 1 then
      self.timer = CurTime()
      self:SetSulfurProgress(self:GetSulfurProgress() + 5)
    end
  end
  if self:GetSulfurProgress() >= 100 then
    local sulfurentity = ents.Create("sulfur")
    sulfurentity:SetPos(pos)
    sulfurentity:Spawn()
    -- Reseting the NetworkVar's
    self:SetPhosphorusAmount(0)
    self:SetMethylaminAmount(0)
    self:SetSulfurProgress(0)
  end
end

-- Checking if the entity has been touched by phosphorus or methylamin
function ENT:StartTouch(toucher)
  if toucher:GetClass() == "phosphorus" then
    self:SetPhosphorusAmount(self:GetPhosphorusAmount() + 50)
    toucher:Remove()
  elseif toucher:GetClass() == "methylamin" then
    self:SetMethylaminAmount(self:GetMethylaminAmount() + 50)
    toucher:Remove()
  else
    return
  end
end
