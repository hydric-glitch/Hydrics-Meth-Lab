ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Sulfur Maker"
ENT.Spawnable = true
ENT.Category = "Hydric's Meth Lab"

function ENT:SetupDataTables()
  self:NetworkVar("Int", 1, "PhosphorusAmount")
  self:NetworkVar("Int", 2, "MethylaminAmount")
  self:NetworkVar("Int", 3, "SulfurProgress")
end
