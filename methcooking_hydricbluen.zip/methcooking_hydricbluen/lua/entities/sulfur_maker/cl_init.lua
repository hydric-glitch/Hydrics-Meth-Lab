include("shared.lua")

surface.CreateFont("hydricsmethlabdisplayfont", {
  font = "Arial",
  size = 13,
  weight = 500
})

function ENT:Draw()
  self:DrawModel()
end

hook.Add("HUDPaint", "hydricsmethlabsulfurmakerhud", function()
  local eye = LocalPlayer():GetEyeTrace()
  -- Checking if the player is looking at the Sulfur Maker
  if eye.Entity:GetClass() == "sulfur_maker" then
    -- Checking the player distance from the Sulfur Maker
    local dist = 200^2
    local waypoint = eye.Entity:GetPos()
    if LocalPlayer():GetPos():DistToSqr(waypoint) < dist then
      waypoint = waypoint:ToScreen()
      -- Drawing the back of the box
      surface.SetDrawColor(0, 0, 0, 100)
      surface.DrawRect(waypoint.x*.95, waypoint.y*.9, 100, 50)
      -- Drawing the name of the entity to the
      draw.SimpleText("Sulfur Maker", "hydricsmethlabdisplayfont", waypoint.x*.95, waypoint.y*.9, color_white, ALIGN_TEXT_CENTER, ALIGN_TEXT_CENTER)
      draw.SimpleText("Progress: " .. eye.Entity:GetSulfurProgress(), "hydricsmethlabdisplayfont", waypoint.x*.95, waypoint.y*.925, Color(255, 255, 255, 255), ALIGN_TEXT_CENTER, ALIGN_TEXT_CENTER)
      draw.SimpleText("Phos. Amount: " .. eye.Entity:GetPhosphorusAmount(), "hydricsmethlabdisplayfont", waypoint.x*.95, waypoint.y*.945, Color(255, 0, 0, 255), ALIGN_TEXT_CENTER, ALIGN_TEXT_CENTER)
      draw.SimpleText("Meth. Amount: " .. eye.Entity:GetMethylaminAmount(), "hydricsmethlabdisplayfont", waypoint.x*.95, waypoint.y*.965, Color(0, 255, 255, 255), ALIGN_TEXT_CENTER, ALIGN_TEXT_CENTER)
    end
  end
end)
